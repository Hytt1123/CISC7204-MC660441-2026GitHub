# 1. Import libraries
import pandas as pd
import dash
from dash import dcc, html, Input, Output
import plotly.express as px

# read the dataset
airline_data = pd.read_csv('https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv',
                          encoding = "ISO-8859-1",
                          dtype={'Div1Airport': str, 'Div1TailNum': str,
                                 'Div2Airport': str, 'Div2TailNum': str})

# creat dash app
app = dash.Dash(__name__)

# 2. Layout
app.layout = html.Div([
    html.H1('Total number of flights to the destination state split by reporting airline',
            style={'font-size':32, 'textAlign':'center'}),

    html.Div(["Input Year: ",
              dcc.Input(id='input-year', value='2010', type='number',
                        style={'height':'50px', 'font-size':35})],
             style={'font-size':32}),

    html.Br(),
    html.Br(),

    html.Div([dcc.Graph(id='bar-plot')])
])

# 3. Callback 
@app.callback(
    Output(component_id='bar-plot', component_property='figure'),
    Input(component_id='input-year', component_property='value')
)

# 4. Define Callback graph function
def get_graph(entered_year):
    df = airline_data[airline_data['Year'] == int(entered_year)]
    bar_data = df.groupby(['DestState', 'Reporting_Airline'])['Flights'].sum().reset_index()
    bar_sum = bar_data.groupby("DestState")["Flights"].sum().reset_index()

    fig = px.bar(bar_sum,
                 x="DestState",
                 y="Flights",
                 title="Flights to Destination State")
    
    fig.update_layout(
        width=1000,
        height=400,
        xaxis=dict(title="DestState")
    )
    return fig

# 5. running the app
if __name__ == '__main__':
    app.run()